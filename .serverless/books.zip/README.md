# Flyreel Book Library

Book library for Flyreel challenge

## Prerequisites

Node, Typescript, Serverless

Install the Serverless Framework via

`npm install -g serverless`

Serverless must be configured with your AWS account in order to deploy

## Compiling

You can compile the ts files in this directory by first installing typescript via

`npm install -g typescript`

then

`npm i`

You can then run the compiler by running `tsc` in this directory. It will pull the settings from .tsconfig and extra @types
from package.json. The output create.js file is what will be uploaded by serverless.

## Deployment

